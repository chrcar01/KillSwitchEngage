﻿using System;
using System.Windows.Controls;

namespace KillSwitchEngage.Controls
{	
	public partial class BusyIndicator : UserControl
	{		
		public BusyIndicator()
		{
			InitializeComponent();
		}	
	}
}
