using System;

namespace KillSwitchEngage.UI.Infrastructure
{
	public enum NavigationDirections
	{
		Forward,
		Backward
	}
}
