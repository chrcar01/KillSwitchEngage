using System;

namespace KillSwitchEngage.UI.Infrastructure
{
	public interface IBusy
	{
		bool IsBusy { get; set; }
	}
}
