using System;

namespace KillSwitchEngage.UI.Infrastructure
{
	public class BusyStatusMessage
	{
		public bool Status { get; set; }
	}
}
